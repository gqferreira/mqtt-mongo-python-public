const axios = require('axios');

exports.handler = async (event) => {
  const webhookUrl = process.env.SLACK_WEBHOOK_URL;

  try {
    for (const record of event.Records) {
      const sns = record.Sns;

      // Tenta parsear o corpo da mensagem como JSON (estrutura padrão do CloudWatch Alarm)
      let alarmDescription = sns.Message;

      try {
        const parsed = JSON.parse(sns.Message);
        if (parsed.AlarmDescription) {
          alarmDescription = parsed.AlarmDescription;
        }
      } catch (parseError) {
        console.warn("Mensagem não era JSON. Usando corpo bruto.");
      }

      // Envia para o Slack
      await axios.post(webhookUrl, {
        text: `🚨 *CloudWatch Alarm*:\n${alarmDescription}`
      });
    }

    console.log("Notificação enviada com sucesso para o Slack");
  } catch (error) {
    console.error("Erro ao enviar notificação para o Slack", error);
    throw error;
  }
};
